#include <stdio.h>
#include <stdlib.h>
#include "vstm.h"
#include "vstmNewTask.h"

void addTask(int argc, char *argv[])
{
	FILE *vstmDB;
	int i;

	vstmDB = initDBFile('r');
	fseek(vstmDB, 0, SEEK_END);
	i = 1;
	while(i < argc)
	{
		fputs(argv[i], vstmDB);
		if(i+1 < argc)
			fputc(' ', vstmDB);
		i++;
	}

	fputc('\n', vstmDB);
	fclose(vstmDB);
}
