#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "vstmListTasks.h"
#include "vstm.h"

void listTasks() // The "biggest" and ugliest function
{
	FILE *vstmDB;
	char buffer[MAX_TASK_LEN+1];
	char priorityBuffer[MAX_TASK_LEN+1];
	int  i, maxID;
	register unsigned int actualID;
	register int bufferEnd;
	register unsigned char maxNumberDigits = 1;
	register int digitsTemp;
	char *whereIsNewline;

	struct task *head = NULL;
	struct task *worker = NULL;
	struct task *temp = NULL;

	vstmDB = initDBFile('r');

	actualID = 0;

	/* strlen(myTask) > 500 ? meh */
	while(fgets(buffer, MAX_TASK_LEN, vstmDB) != NULL)
	{
		whereIsNewline = strchr(buffer, '\n');

		if(whereIsNewline)
			*whereIsNewline = '\0';
		if(buffer == '\0')
			break;
		if((temp = malloc(sizeof(*temp))) == NULL)
			error("Not enough mem");/* NOTREACHED */
		if((temp->desc = malloc(sizeof(temp->desc)*(strlen(buffer)+1)))
		    == NULL)
			error("Not enough mem");/* NOTREACHED */

		i = 0;
		bufferEnd = 0;
		digitsTemp = 1;
		if(buffer[0] == '@') /* starting with @PRIO or @H or @L */
		{
			i = 1;
			while(buffer[i] != ' ' && buffer[i] != EOF && buffer[i]
			       != '\n')
			{
				priorityBuffer[i-1] = buffer[i];
				i++;
			}

			priorityBuffer[i-1] = '\0';
			bufferEnd = i+1;
			i = 0; /* Now priority */

			if(isNumeric(priorityBuffer))
			{
				i = atoi(priorityBuffer);
				digitsTemp = countNumberDigits(i);
			}
			else /* only content */
			{
				digitsTemp = 1;
				switch(priorityBuffer[0])
				{
					case 'H':
						i = H;
						break;
					case 'L':
						i = L;
						break;
					default:
						i = 0;
				}
			}
			/* And count the number of digits */
			//digitsTemp = (unsigned char)strlen(priorityBuffer)-1;

			if(digitsTemp > maxNumberDigits)
				maxNumberDigits = digitsTemp;
		}

		temp->priority = i;
		temp->n = NULL;
		temp->ID = actualID;
		actualID++;
		memcpy(temp->desc, buffer+bufferEnd, strlen(buffer+bufferEnd));

		if(!head) /* new linked list */
			head = temp;
		else /* sort while inserting */
		{
			worker = head;
			/* SORTING_OP : < OR > */
			if(temp->priority SORTING_OP head->priority)
			{
				temp->n = head;
				head = temp;
			}
			else
			{
				while(worker->n != NULL)
				{
					if(temp->priority SORTING_OP
					    worker->n->priority)
						break;
					else
						worker = worker->n;
				}
				temp->n = worker->n;
				worker->n = temp;
			}
		}
	} /* end of task acquisitions */

	maxID = countNumberDigits(--actualID);
	fclose(vstmDB);

	fputs(BLUE"Here's your TODO list:\n"NORMAL, stderr);

	temp = head;
	maxNumberDigits++;
	while(temp != NULL)
	{
		/* first, display the task's ID */
		printf("%d", temp->ID);
		i = maxID - countNumberDigits(temp->ID);
		while(i-- > 0) //spacing of the IDs
			putc(' ', stderr);
		putchar(' '); /* a minimal spacing */

		chooseColor(temp->priority);
		switch(temp->priority)
		{
			case H:
				putchar('H'); break;
			case L:
				putchar('L'); break;
			default:
				printf("%d", temp->priority);
		}
		printf(NORMAL);

		if(temp->priority == H || temp->priority == L)
			i = maxNumberDigits - 1;
		else
			i = maxNumberDigits-countNumberDigits(temp->priority);
//		while(i--) /* spacing for the priorities */
//			putc(' ', stderr); //FIXME
		putchar(' ');

		printf("%s", temp->desc);
		temp = temp->n;
		printf("\n");
	}
	if(!head)
		fprintf(stderr, RED"No tasks\n"NORMAL);

	/*free the list*/
	while(head)
	{
		free(head->desc);
		temp = head->n;
		free(head);
		head = temp;
	}
}
