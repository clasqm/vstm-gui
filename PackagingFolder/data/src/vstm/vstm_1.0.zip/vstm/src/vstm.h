#ifndef VSTM_H
#define VSTM_H

#define VERSION "1.0"
#define DB_FILE "/.vstmDB"
#define LIST_T   0 /* $ vstm */
#define DELETE_T 1 /* $ vstm ID */
#define ADD_T    2 /* $ vstm My task to add */
#define HELP     3 /* $ vstm ? */

#define SORTING_OP <

#define RED    "\033[;31m"
#define GREEN  "\033[;32m"
#define YELLOW "\033[;33m"
#define BLUE   "\033[;34m"
#define OTHER  "\033[;35m"
#define NORMAL "\033[;m"

#define H 99999999
#define L -99999999

#define MAX_TASK_LEN 500


struct task
{
	char *desc;
	int priority;
	unsigned int ID;
	struct task *n;
};

struct simpleList
{
	char *task;
	struct simpleList *n;
};

/* VSTM's functions */
FILE *initDBFile(char choice);
char *returnDBPath();
void listTasks();
void deleteTasks(int argc, char *argv[]);
void addTask(int argc, char *argv[]);
void displayHelp();

int  whichChoice(int argc, char *argv[]);
int  isNumeric(char string[]);
int  countNumberDigits(int number);
void chooseColor(int prio); 
void error(char *reason);

#endif
