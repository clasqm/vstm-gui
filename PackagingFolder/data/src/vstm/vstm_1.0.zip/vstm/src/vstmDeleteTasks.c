#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "vstmDeleteTasks.h"
#include "vstm.h"
/*
 * this function deletes the tasks scheduled for deletion
 * and, in the meantine, "cleans" the vstmDB's file for empty lines
 */

void deleteTasks(int argc, char *argv[])
{
/* THIS FUNCTION IS SOOOOO INEFICIENT...
 * CONSIDER MAYBE REWRITING IT..*/

	FILE *vstmDB;
	unsigned int *tasksToDelete = NULL;
	struct simpleList *head = NULL;
	struct simpleList *temp = NULL;
	struct simpleList *next = NULL;
	struct simpleList *toDelete= NULL;
	register unsigned int i, j, skip, length;
	char buffer[MAX_TASK_LEN+1];

	vstmDB = initDBFile('r');

	/* first, going to create an array with numbers */
	tasksToDelete = malloc(sizeof(*tasksToDelete)*(argc - 1));
	i = 1;
	while(i < (unsigned int)argc) /* putting argv in tasksToDelete */
	{
		tasksToDelete[i-1] = (unsigned int)atoi(argv[i]);
		i++;
	}

	/* read the DBFile, now */
	i = 0;
	while(fgets(buffer, MAX_TASK_LEN, vstmDB) != NULL) /* read the file */
	{
		j = 0; skip = 0;

		if(buffer[0] == '\n') /* a single \n : shouldn't happen */
		{
			fprintf(stderr, "skipped %d\n", i);
			skip = 1;
		}
		length = (unsigned int)strlen(buffer);

		if(buffer[length - 1] == '\n') //trailing \n's
			buffer[length - 1] = '\0';

		/* do we want the task deleted ? */
		while(j < (unsigned int)(argc - 1))
		{
			if(tasksToDelete[j] == i)
			{
				skip = 1;
				break;
			}
			j++;
		}

		/* don't want to delete this task->put it in linked list */
		if(!skip)
		{
			if((temp = malloc(sizeof(*temp))) == NULL)
			{
				error("Not enough mem");/* NOTREACHED */
			}

			if((temp->task = malloc(sizeof(char)*length)) == NULL)
			{
				error("Not enough mem");/* NOTREACHED */
			}
	
			memcpy(temp->task, buffer, length);
			temp->n = NULL;
			if(!head)
			{
				head = temp;
				next = head;
			}
			else
			{
				next->n = temp;
				next = temp;
			}
		}
		i++; /*increment task number */
	}

	fclose(vstmDB);

	/* Now, delete task file & rewrite them */
	/* Hope the computer doesn't crash now :D */
	vstmDB = initDBFile('d');
	temp = head;
	while(temp)
	{
		fputs(temp->task, vstmDB);
		fputc('\n', vstmDB);
		toDelete = temp;
		temp = temp->n;
		free(toDelete->task);
		free(toDelete);
	}
	free(tasksToDelete);
	fclose(vstmDB);
}
