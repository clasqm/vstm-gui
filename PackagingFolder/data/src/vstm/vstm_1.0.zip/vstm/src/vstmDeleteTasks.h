#ifndef VSTM_DELETE_TASKS
#define VSTM_DELETE_TASKS

void deleteTasks(int argc, char *argv[]);

#endif
