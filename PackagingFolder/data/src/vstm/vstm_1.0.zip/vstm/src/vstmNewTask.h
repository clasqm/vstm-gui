#ifndef VSTM_NEW_TASK
#define VSTM_NEW_TASK
/* yeah, that's verbose.. */
void addTask(int argc, char *argv[]);

#endif
