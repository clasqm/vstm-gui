/*
 * VSTM - Very Simple Todo Manager
 * How to simply keep track of tasks to do
 * Frank Villaro-Dixon - 2012
 * -- CODING STYLE
 * ONE thing: For identation, tabs, not spaces please..
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "vstm.h"
#include "vstmNewTask.h"
#include "vstmListTasks.h"
#include "vstmDeleteTasks.h"

int main(int argc, char *argv[])
{
	switch(whichChoice(argc, argv))
	{
		case LIST_T:
			listTasks();
			break;
		case DELETE_T:
			deleteTasks(argc, argv);
			break;
		case ADD_T:
			addTask(argc, argv);
			break;
		default:
			displayHelp();
	}
	return EXIT_SUCCESS;
}

int whichChoice(int argc, char *argv[])
{
/* We want to keep it simple. No funny options (getopt, etc..).
If you want to add a simple thing, the best should be to recompile
'll have to think about-it*/
	int i;
	if(argc <= 1)
		return LIST_T;
		/* NOTREACHED */
	else if(argc == 2) /* either delete, help, or add task */
	{
		if(argv[1][0] == '?' ||
		   argv[1][1] == '?' ||
		   (argv[1][0] == '-' && argv[1][1] == 'h'))
		/* ? or *? */
			return HELP;
			/* NOTREACHED */
		else if(isNumeric(argv[1]))
			return DELETE_T;
			/* NOTREACHED */
		else
			return ADD_T;
			/* NOTREACHED */
	}

	/* more than 2 args -> new task or multiple deletes */
	i = 1;
	while(i < argc)
	{
		if(!isNumeric(argv[i]))
			return ADD_T;
			/* NOTREACHED */
		i++;
	}
	// only numerics, it's a delete
	return DELETE_T;
}

int isNumeric(char string[])
{
	int c = 0;
	while(string[c] != '\0')
	{
		if(string[c] < '0' || string[c] > '9')
			if(!(c == 0 && string[0] == '-')) /* clearer"  */
				return 0;
		c++;
	}
	return 1;
}

FILE *initDBFile(char choice)
{
	/*
	 * TODO First, checks if CUR_DIR/.vstmDB exists
	 * if true -> use this file
	 * else, tries to open/create the DB file
	 * named: ~/.vstmDB
	 */
	FILE *vstmDB;
	char *vstmDBPath;

	vstmDBPath = returnDBPath();
	if(choice == 'd') /* with 'd', make sure the tasks are saved */
	{
		if(unlink(vstmDBPath)) /* can't "delete" file */
			perror("Unlink: unable to delete file...");
	}

	if((vstmDB = fopen(vstmDBPath, "r+")) == NULL)/* file does not exist */
	{
		if((vstmDB = fopen(vstmDBPath, "w+")) == NULL)
		{
			perror("Could not create file...");
			fprintf(stderr, "Could not open/create file %s\n",
			        vstmDBPath);
		}
	}
	free(vstmDBPath);
	return vstmDB;
}

char *returnDBPath()
{
	char *userHome;
	char *vstmDBPath;
	char *dirName;
	int DBPathLength;
	int pathLen;
	static int warned = 0;


	// first, try with current working directory
	//get_current_dir_name doesn't work ?!
//	dirName = get_current_dir_name();
	char my_cwd[1024];
	getcwd(my_cwd, 1024);
	dirName = my_cwd;


	pathLen = strlen(dirName);

	DBPathLength = pathLen + strlen(DB_FILE) + 3;
	vstmDBPath = calloc(DBPathLength, sizeof(*vstmDBPath));

	memcpy(vstmDBPath, dirName, pathLen);
	strcat(vstmDBPath, DB_FILE);
//	free(dirName); //FIXME if get_current_dir_name()

//	if(fopen(vstmDBPath, "r") == NULL) //yuck
	if(access(vstmDBPath, R_OK))
	{
		free(vstmDBPath);

		if((userHome = getenv("HOME")) == NULL)
			perror("Could not get HOMV env. var..\nPlease set it");

		DBPathLength = strlen(userHome) + strlen(DB_FILE) + 2;
		vstmDBPath = calloc(DBPathLength, sizeof(*vstmDBPath));
		memcpy(vstmDBPath, userHome, strlen(userHome));
		strcat(vstmDBPath, DB_FILE);
	}
	else if(!warned)
	{
		warned = 1;
		fputs(OTHER"(Using local file)"NORMAL"\n", stderr);
	}
	return vstmDBPath;
}

int countNumberDigits(int number)
{
	if(number < 0)
		number *= -10; /* make positive and add digit (-) */

	if(number <= 9)
		return 1;
	else if(number <= 99)
		return 2;
	else if(number <= 999)
		return 3;
	else if(number <= 9999)
		return 4;
	else if(number <= 99999)
		return 5;
	else if(number <= 999999)
		return 6;
	return 7; //yeah, that's awful, right ?
}

void chooseColor(int prio)
{
	if(prio > 0)
		printf(RED); /* can't puts() cos' "\n" */
	else if(prio == 0)
		printf(YELLOW);
	else
		printf(GREEN);
}

void displayHelp() //should update that
{
	printf("vstm - Very Simple Todo Manager version %s \n"
"Frank Villaro-Dixon - 2013 \n "
"\n"
"vstm is a simple todo manager who keeps your TODO things\n"
"\n"
"To add a todo:\n"
"$ vstm [@priority] message\n"
"\n"
"priority sets the task priority. It can be either a number, H (for high) or L.\n"
"Each TODO task is assigned a non static ID number\n"
"\n"
"To see the actual TODOs:\n"
"$ vstm\n"
"\n"
"To delete a TODO:\n"
"$vstm ID [ID2] [ID3]\n", VERSION);
}

void error(char *reason)
{
	fputs(reason, stderr);
	exit(EXIT_FAILURE);
	/* NOTREACHED */
}
